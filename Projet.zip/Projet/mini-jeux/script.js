// MINI-JEU : ÉCHELLE DE MOHS
const minerals = [
    { name: "Talc", hardness: 1, color: "Blanc, Vert pâle", use: "Cosmétiques, poudre pour bébé", image: "images/talc.jpg" },
    { name: "Gypse", hardness: 2, color: "Blanc, Gris", use: "Plâtre, engrais", image: "images/gypse.jpg" },
    { name: "Calcite", hardness: 3, color: "Blanc, Jaune, Vert", use: "Ciment, pierres décoratives", image: "images/calcite.jpg" },
    { name: "Fluorite", hardness: 4, color: "Vert, Violet, Jaune", use: "Industrie chimique, optique", image: "images/fluorite.jpg" },
    { name: "Apatite", hardness: 5, color: "Vert, Jaune, Bleu", use: "Engrais (phosphates)", image: "images/apatite.jpg" },
    { name: "Orthose", hardness: 6, color: "Rose, Blanc, Gris", use: "Céramique, verre", image: "images/orthose.jpg" },
    { name: "Quartz", hardness: 7, color: "Transparent, Blanc, Rose", use: "Montres, électronique, verre", image: "images/quartz.jpg" },
    { name: "Topaze", hardness: 8, color: "Bleu, Jaune, Transparent", use: "Bijouterie", image: "images/topaze.jpg" },
    { name: "Corindon", hardness: 9, color: "Rouge (Rubis), Bleu (Saphir)", use: "Bijouterie, abrasifs", image: "images/corindon.jpg" },
    { name: "Diamant", hardness: 10, color: "Transparent", use: "Bijouterie, industrie (découpe)", image: "images/diamant.jpg" }
];

function searchMineral() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "";

    let foundMinerals = minerals.filter(m => m.name.toLowerCase().includes(input));

    if (foundMinerals.length > 0) {
        foundMinerals.forEach(mineral => {
            let card = document.createElement("div");
            card.classList.add("mineral-card");
            card.innerHTML = `
                <img src="${mineral.image}" alt="${mineral.name}" class="mineral-image">
                <p><strong>Nom :</strong> ${mineral.name}</p>
                <p><strong>Dureté :</strong> ${mineral.hardness}</p>
                <p><strong>Couleur :</strong> ${mineral.color}</p>
                <p><strong>Utilisation :</strong> ${mineral.use}</p>
            `;
            resultDiv.appendChild(card);
        });
    } else {
        resultDiv.innerHTML = "<p style='color:red;'>Aucun minéral trouvé.</p>";
    }
}

function showAllMinerals() {
    let resultDiv = document.getElementById("result");
    resultDiv.innerHTML = "";

    minerals.sort((a, b) => a.hardness - b.hardness).forEach(mineral => {
        let card = document.createElement("div");
        card.classList.add("mineral-card");
        card.innerHTML = `
            <img src="${mineral.image}" alt="${mineral.name}" class="mineral-image">
            <p><strong>Nom :</strong> ${mineral.name}</p>
            <p><strong>Dureté :</strong> ${mineral.hardness}</p>
            <p><strong>Couleur :</strong> ${mineral.color}</p>
            <p><strong>Utilisation :</strong> ${mineral.use}</p>
        `;
        resultDiv.appendChild(card);
    });
}
