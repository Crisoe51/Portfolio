// MINI-JEU : NOMBRE MYSTÈRE
let mysteryNumber = Math.floor(Math.random() * 100) + 1;

function checkGuess() {
    let input = document.getElementById("guessInput").value;
    let feedback = document.getElementById("feedback");

    if (input == mysteryNumber) {
        feedback.textContent = "Bravo ! Vous avez trouvé le nombre mystère.";
        feedback.style.color = "green";
    } else if (input > mysteryNumber) {
        feedback.textContent = "Trop haut ! Essayez encore.";
        feedback.style.color = "red";
    } else {
        feedback.textContent = "Trop bas ! Essayez encore.";
        feedback.style.color = "red";
    }
}
