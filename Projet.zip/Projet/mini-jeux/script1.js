// MINI-JEU : QUIZ JAVASCRIPT
const questions = [
    { 
        question: "Quel langage est utilisé pour styliser un site web ?", 
        answers: ["HTML", "CSS", "JavaScript"], 
        correct: "CSS" 
    },
    { 
        question: "Que signifie DOM ?", 
        answers: ["Document Object Model", "Data Oriented Module", "Document Order Method"], 
        correct: "Document Object Model" 
    },
    { 
        question: "Comment sélectionne-t-on un élément par son ID en JavaScript ?", 
        answers: ["getElementById()", "querySelector()", "getElementByClass()"], 
        correct: "getElementById()" 
    }
];

let currentQuestionIndex = 0;

function showQuestion() {
    let questionContainer = document.getElementById("question-container");
    let questionText = document.getElementById("question-text");
    let answersDiv = document.getElementById("answers");

    let q = questions[currentQuestionIndex];
    questionText.textContent = q.question;
    answersDiv.innerHTML = "";

    q.answers.forEach(answer => {
        let btn = document.createElement("button");
        btn.textContent = answer;
        btn.classList.add("btn");
        btn.onclick = () => checkAnswer(answer);
        answersDiv.appendChild(btn);
    });
}

function checkAnswer(answer) {
    if (answer === questions[currentQuestionIndex].correct) {
        alert("Bonne réponse !");
    } else {
        alert("Mauvaise réponse !");
    }
    nextQuestion();
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        alert("Quiz terminé !");
        currentQuestionIndex = 0;
        showQuestion();
    }
}

document.addEventListener("DOMContentLoaded", showQuestion);
